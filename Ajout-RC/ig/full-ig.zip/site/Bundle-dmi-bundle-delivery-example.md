# dmi-bundle-delivery-example - Traçabilité des Dispositifs Médicaux Implantables v3.0.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **dmi-bundle-delivery-example**

## Example Bundle: dmi-bundle-delivery-example



## Resource Content

```json
{
  "resourceType" : "Bundle",
  "id" : "dmi-bundle-delivery-example",
  "meta" : {
    "profile" : ["https://interop.esante.gouv.fr/ig/fhir/tdmi/StructureDefinition/dmi-bundledelivery"]
  },
  "type" : "transaction",
  "entry" : [{
    "fullUrl" : "https://test-server.fr/SupplyDelivery/dmi-supplydelivery-transport-example",
    "resource" : {
      "resourceType" : "SupplyDelivery",
      "id" : "dmi-supplydelivery-transport-example",
      "meta" : {
        "profile" : ["https://interop.esante.gouv.fr/ig/fhir/tdmi/StructureDefinition/dmi-supplydelivery-transport"]
      },
      "text" : {
        "status" : "extensions",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"SupplyDelivery_dmi-supplydelivery-transport-example\"> </a><p class=\"res-header-id\"><b>Narratif généré : Supply Livraison dmi-supplydelivery-transport-example</b></p><a name=\"dmi-supplydelivery-transport-example\"> </a><a name=\"hcdmi-supplydelivery-transport-example\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profil: <a href=\"StructureDefinition-dmi-supplydelivery-transport.html\">DMISupplyDeliveryTransport</a></p></div><p><b>DMIReferenceOrganisationInterne</b>: <a href=\"Organization-dmi-organization-interne-example.html\">Organization DMI Organization Interne Example Name</a></p><blockquote><p><b>DMITransport</b></p><ul><li>refTransport: identifier-reftransport-example</li><li>refDelivery: identifier-refdelivery-example</li><li>meta: Pas d'affichage pour Meta  (versionId : meta-versionid-example)</li></ul></blockquote><p><b>identifier</b>: identifier-dmi-supplydelivery-transport-example</p><p><b>status</b>: Delivered</p><h3>SuppliedItems</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Item[x]</b></td></tr><tr><td style=\"display: none\">*</td><td><a href=\"Device-dmi-device-example.html\">Device : extension = IPIdLogiciel example,</a></td></tr></table><p><b>occurrence</b>: 2026-02-24</p><p><b>receiver</b>: <a href=\"Practitioner-dmi-practitioner-example.html\">Practitioner : identifier = http://www.acme.com/identifiers#identifier-dmi-practitioner-example; telecom = dmi-practitioner-example@example.com</a></p></div>"
      },
      "extension" : [{
        "url" : "https://interop.esante.gouv.fr/ig/fhir/tdmi/StructureDefinition/dmi-reference-organisation-interne",
        "valueReference" : {
          "reference" : "Organization/dmi-organization-interne-example"
        }
      },
      {
        "extension" : [{
          "url" : "refTransport",
          "valueIdentifier" : {
            "value" : "identifier-reftransport-example"
          }
        },
        {
          "url" : "refDelivery",
          "valueIdentifier" : {
            "value" : "identifier-refdelivery-example"
          }
        },
        {
          "url" : "meta",
          "valueMeta" : {
            "versionId" : "meta-versionid-example"
          }
        }],
        "url" : "https://interop.esante.gouv.fr/ig/fhir/tdmi/StructureDefinition/dmi-transport"
      }],
      "identifier" : [{
        "value" : "identifier-dmi-supplydelivery-transport-example"
      }],
      "status" : "completed",
      "suppliedItem" : {
        "itemReference" : {
          "reference" : "Device/dmi-device-example"
        }
      },
      "occurrenceDateTime" : "2026-02-24",
      "receiver" : [{
        "reference" : "Practitioner/dmi-practitioner-example"
      }]
    },
    "request" : {
      "method" : "POST",
      "url" : "DMISupplyDeliveryTransport"
    }
  },
  {
    "fullUrl" : "https://test-server.fr/SupplyDelivery/dmi-supplydelivery-ligne-example",
    "resource" : {
      "resourceType" : "SupplyDelivery",
      "id" : "dmi-supplydelivery-ligne-example",
      "meta" : {
        "profile" : ["https://interop.esante.gouv.fr/ig/fhir/tdmi/StructureDefinition/dmi-supplydelivery-ligne"]
      },
      "text" : {
        "status" : "extensions",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"SupplyDelivery_dmi-supplydelivery-ligne-example\"> </a><p class=\"res-header-id\"><b>Narratif généré : Supply Livraison dmi-supplydelivery-ligne-example</b></p><a name=\"dmi-supplydelivery-ligne-example\"> </a><a name=\"hcdmi-supplydelivery-ligne-example\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profil: <a href=\"StructureDefinition-dmi-supplydelivery-ligne.html\">DMISupplyDeliveryLigne</a></p></div><p><b>DMIReferenceOrganisationInterne</b>: <a href=\"Organization-dmi-organization-interne-example.html\">Organization DMI Organization Interne Example Name</a></p><p><b>identifier</b>: identifier-dmi-supplydelivery-ligne-example</p><p><b>basedOn</b>: <a href=\"SupplyRequest-dmi-supplyrequest-entete-commande-example.html\">SupplyRequest : identifier = identifier-dmi-supplyrequest-entete-commande-example; item[x] = Commande de dispositifs médicaux; quantity = 2</a></p><p><b>partOf</b>: <a href=\"SupplyDelivery-dmi-supplydelivery-entete-livraison-example.html\">SupplyDelivery : extension = -&gt;Organization DMI Organization Interne Example Name; identifier = identifier-dmi-supplydelivery-entete-livraison-example; status = completed; occurrence[x] = 2026-02-24</a></p><p><b>status</b>: Delivered</p><h3>SuppliedItems</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Item[x]</b></td></tr><tr><td style=\"display: none\">*</td><td><a href=\"Device-dmi-device-example.html\">Device : extension = IPIdLogiciel example,</a></td></tr></table><p><b>occurrence</b>: 2026-02-24</p><p><b>receiver</b>: <a href=\"Practitioner-dmi-practitioner-example.html\">Practitioner : identifier = http://www.acme.com/identifiers#identifier-dmi-practitioner-example; telecom = dmi-practitioner-example@example.com</a></p></div>"
      },
      "extension" : [{
        "url" : "https://interop.esante.gouv.fr/ig/fhir/tdmi/StructureDefinition/dmi-reference-organisation-interne",
        "valueReference" : {
          "reference" : "Organization/dmi-organization-interne-example"
        }
      }],
      "identifier" : [{
        "value" : "identifier-dmi-supplydelivery-ligne-example"
      }],
      "basedOn" : [{
        "reference" : "SupplyRequest/dmi-supplyrequest-entete-commande-example"
      }],
      "partOf" : [{
        "reference" : "SupplyDelivery/dmi-supplydelivery-entete-livraison-example"
      }],
      "status" : "completed",
      "suppliedItem" : {
        "itemReference" : {
          "reference" : "Device/dmi-device-example"
        }
      },
      "occurrenceDateTime" : "2026-02-24",
      "receiver" : [{
        "reference" : "Practitioner/dmi-practitioner-example"
      }]
    },
    "request" : {
      "method" : "POST",
      "url" : "DMISupplyDeliveryLigne"
    }
  }]
}

```
