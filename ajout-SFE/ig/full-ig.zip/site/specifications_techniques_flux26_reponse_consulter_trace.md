# Flux 26 - ReponseConsulterTrace - Traçabilité des Dispositifs Médicaux Implantables v3.0.0

* [**Table of Contents**](toc.md)
* [**Volume 2 - Détail des transactions**](specifications_techniques_introduction.md)
* **Flux 26 - ReponseConsulterTrace**

## Flux 26 - ReponseConsulterTrace

